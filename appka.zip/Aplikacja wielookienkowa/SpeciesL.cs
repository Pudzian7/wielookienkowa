﻿namespace Aplikacja_wielookienkowa
{
    public enum SpeciesL
    {

    }
}
