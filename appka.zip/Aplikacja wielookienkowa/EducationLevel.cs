﻿namespace Aplikacja_wielookienkowa
{
    public class SpeciesL
    {
    }
}