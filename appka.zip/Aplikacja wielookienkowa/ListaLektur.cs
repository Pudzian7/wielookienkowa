﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplikacja_wielookienkowa
{
    internal class ListaLektur
    {
        public ObservableCollection<Lektura> lektury;

        public ListaLektur()
        {
            lektury = new ObservableCollection<Lektura>();
            LoadLektury("plik.txt");
        }

        public void AddLektura(Lektura lektura)
        {
            lektury.Add(lektura);
        }
        public void RemoveLektura(Lektura lektura)
        {
            lektury.Remove(lektura);
        }
        public void EditLektura(int index, Lektura lektura)
        {
            lektury[index] = lektura;
        }
        public void RemoveLekturaAt(int index)
        {
            if(index >= 0 && index < lektury.Count)
                lektury.RemoveAt(index);
        }
        public void LoadLektury(string file)
        {
            lektury.Clear();
            lektury.Add(new Lektura("Baśniobór", "Leopez", SpeciesL.fantastyczna));
            lektury.Add(new Lektura("Makbet", "Sfneaf", SpeciesL.dramat));
        }
        public void SaveLektury(string file)
        {

        }

    }
}












