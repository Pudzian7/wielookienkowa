﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Aplikacja_wielookienkowa
{
    internal class Lektura
    {
        public string Tytuł { get; set; } = string.Empty;
        public string Autor { get; set; } = string.Empty;

        public SpeciesL Species { get; set; } = 0;
        
        public Lektura() 
        { 
        }

        public Lektura(string tytuł, string autor, SpeciesL species)
        {
            Tytuł = tytuł;
            Autor = autor;
            Species = species;
        }
        public override string ToString()
        {
            return Tytuł + " " + Autor + " " + Species.ToString();
        }
    }

    public enum SpeciesL
    {
        dramat=0,
        historyczna=1,
        miłosna=2,
        fantastyczna=3,
    }


}

        